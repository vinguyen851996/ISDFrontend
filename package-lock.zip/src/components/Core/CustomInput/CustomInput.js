import React from 'react';
import PropTypes from 'prop-types';


const CustomInput = () => {
    return (
        <div>
            
            
        </div>
    );
};


CustomInput.propTypes = {

};


export default CustomInput;
