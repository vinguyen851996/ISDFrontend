import LoginPage from '../src/pages/Auth/LoginPage';


var routes = [
  {
    path: '/login',
    name: 'Login',
    // icon: LockOpenIcon,
    component: LoginPage,
    layout: '/auth',
  },


];
export default routes;
